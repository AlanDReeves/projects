package edu.ics111.h07;

import java.util.Scanner;

/**
 * This class holds player data for TwoDicePigGame.
 * It also executes turns to calculate scores.
 * @author Alan Reeves.
 */
public class Player {
  private String name;
  private int score;
  
  /**
   * This method is the constructor for the class Player.
   * @param name is the player's name.
   * @param score is the player's score.
   */
  public Player(String name, int score) {
    this.name = name;
    this.score = score;
  } //end of constructor
  
  /**
   * This method rolls two 6 sided dice.
   * @return an array containing the values of the two rolls.
   */
  public int[] rollDice() {
    int[] rolls = new int[2];
    rolls[0] = (int) (Math.random() * 6) + 1;
    rolls[1] = (int) (Math.random() * 6) + 1;
    return rolls;
  } // end rollDice
  //This method is no longer used and an exact copy can be found in class PairOfDice.
  
  /**
   * This method adds to the player's score.
   * @param newScore is the number to add to the score.
   */
  public void addScore(int newScore) {
    this.score += newScore;
  } //end of addScore
  
  /**
   * This method gets the score of the player.
   * @return the player's current score.
   */
  public int getScore() {
    return this.score;
  } //end of getScore
  
  /**
   * This method gets the name of the player.
   * @return the player's name.
   */
  public String getName() {
    return this.name;
  } //end of getName
  
  /**
   * This method gives a player a turn, allowing them to score and hold, etc.
   * No values are returned because all variables are in this class.
   * @param keyboard is used to take input during the turn.
   */
  
  public void playerTurn(Scanner keyboard, int turnScore) {
    //ask player to roll or hold
    boolean turnOver = false;
    
    while (!turnOver) {
    
      System.out.println(this.name + " It is your turn.");
      System.out.println("Would you like to roll or hold?");
      System.out.println("1 - roll");
      System.out.println("2 - hold");
    
      //store and interpret answer
      int input = 0;
      boolean done = false;
      while (!done) {
        try {
          input = keyboard.nextInt();
          if (input == 1 || input == 2) {
            done = true;
          } else {
            System.out.println("Please enter either 1 or 2");
          }
        } catch (java.util.InputMismatchException e) {
          System.out.println("You must input either 1 or 2");
          keyboard.nextLine();
        } //end of catch
    
      } // end of try/catch while
    
      //if roll, roll 2 dice
      if (input == 1) {
        turnScore = forceRoll(turnScore);
        if (turnScore == 0) {
          turnOver = true;
        } //should end turn correctly
      
        //end of it input == 1
      
      } else { // if hold, turn total added to score, turn ends
        this.score += turnScore;
        System.out.println("You hold. Your overall score is now: " + this.score);
        turnOver = true;
      
      } //end of HOLD else
    
    
    
    } // turnOver while end
    
  } //end runTurn
  
  /**
   * This method is used for a forced roll and does not allow the user to hold.
   * @param turnScore is the turn score prior to the roll.
   * @return resulting score after the forced roll.
   */
  public int forceRoll(int turnScore) {
    int[] rolls = PairOfDice.rollDice();
    
    //if two 1s rolled, score = 0 and end turn
    if (rolls[0] == 1 && rolls[1] == 1) {
      System.out.println("You rolled both ones!");
      System.out.println("Your total score is now 0");
      this.score = 0;
      return 0;
      
      //end of two 1s
    } else if (rolls[0] == 1 || rolls[1] == 1) {
      //if single 1 rolled, score += 0, end turn
      System.out.println("You rolled " + rolls[0] + " and " + rolls[1]);
      System.out.println("Your score stays at " + this.score + " and your turn ends");
      return 0;
      
    //end of one 1
    } else if (rolls [0] == rolls[1]) {
      //if double roll, add to turn total and force roll again
      System.out.println("You rolled " + rolls[0] + " and " + rolls[1]);
      System.out.println("You got doubles!");
      System.out.println("Your turn score increases by " + (rolls[0] + rolls[1]));
      turnScore += rolls[0] + rolls[1];
      System.out.println("Roll again!");
      System.out.println();
      turnScore = forceRoll(turnScore);
      
      return turnScore;
      
      //end of if double roll
    
    } else { //if any other numbers, add to total for turn, continue turn.
      System.out.println("You rolled " + rolls[0] + " and " + rolls[1]);
      System.out.println("Your turn score increases by " + (rolls[0] + rolls[1]));
      System.out.println("Your turn continues.");
      turnScore += rolls[0] + rolls[1];
      return turnScore;
    } // end of else
  } //end of forcedRoll
  
  
} //end class
