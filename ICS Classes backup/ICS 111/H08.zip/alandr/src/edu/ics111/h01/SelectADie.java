package edu.ics111.h01;

import java.util.Random;
import java.util.Scanner;


/**
 * A simulation that lets a user decide how many sides are on two dice.
 * @author Alan Reeves
 */
public class SelectADie {
  
  /**
   * This is the main method.
   * @param args not used.
   */
  public static void main(String[] args) {
    Random rand = new Random(); //Creates a random object for later rolls
    @SuppressWarnings("resource")
    Scanner keyboard = new Scanner(System.in); //Sets up scanner to receive input
    
    System.out.print("Please enter a positive integer. "); 
    System.out.println("This will represent the number of sides on two dice.");
    
    String input = keyboard.nextLine();
    int sides = Integer.parseInt(input);
    //Creates a variable to receive the number of sides as a string and then makes it an integer
    
    int die1 = rand.nextInt(sides) + 1;
    int die2 = rand.nextInt(sides) + 1;
    int sum = die1 + die2;
    
    System.out.println("Your first die comes up " + die1);
    System.out.println("Your second die comes up " + die2);
    System.out.println("Your total roll is " + sum);
    if (die1 == die2) {
      System.out.print("Your rolls matched!");  //Fun message
    }
  }
}
//This class is based on code from the class web site.