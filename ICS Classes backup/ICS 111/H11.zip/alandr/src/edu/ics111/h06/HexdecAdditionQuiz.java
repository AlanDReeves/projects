package edu.ics111.h06;

import java.util.Random;
import java.util.Scanner;

/**
 * This class asks the user a series of addition questions based on hexadecimal numbers.
 * At the end it calculates a score with 10 points per question.
 * @author Alan Reeves
 */
public class HexdecAdditionQuiz {

  
  
  /**
   * This is the main method.
   * @param args is not used.
   */
  public static void main(String[] args) {
    // TODO Auto-generated method stub
    System.out.println("This program will ask you a series of hexadecimal addition questions");
    System.out.println("Make sure you answer in hexadecimal.");
    
    int[] firstNum = new int[10];
    int[] secondNum = new int[10];
    int[] answers = new int[10];
    
    Scanner keyboard = new Scanner(System.in);
    
    //generate a series of numbers for questions
    firstNum = numMaker();
    secondNum = numMaker();
    
    //generate a list of answers to the questions
    answers = sumMaker(firstNum, secondNum);
    
    //ask the user questions one at a time
    int[] userInput = new int[10];
    
    for (int inc = 0; inc < 10; inc++) {
      System.out.println("What is the sum of these two numbers?");
      System.out.printf("%2X\n", firstNum[inc]);
      System.out.printf("%2X\n", secondNum[inc]);
      
      //save the user's answers
      String input = "0";
      int inputInt = 0;
      boolean done = false;
      
      
      while (!done) {
        input = keyboard.nextLine();
        try {
          inputInt = Integer.parseInt(input,16);
          done = true;
        } catch (java.lang.NumberFormatException e) {
          System.out.println("Please input a number in hexadecimal.");
        } //end of catch
      } //end of while loop
      userInput[inc] = inputInt;
      
      //above while loop based on coding suggestion from TA Vincent Chan.     
    } //end of inc loop
    
    
    //show the questions again with user's answers
    //compare the user's answers against correct answers
    reviewer(firstNum, secondNum, answers, userInput);
    
    //calculate points and report points (10 per question)
    int score = grader(answers, userInput);
    System.out.println("You scored " + score + " points!");

    keyboard.close();
    
  } //end of main
  
  
  
  
  
  /**
   * This method makes a random array of integers between 1 and 100.
   * @return the array of random numbers, length 10.
   */
  static int[] numMaker() {
    Random rand = new Random();
    int[] nummers = new int[10];
    for (int i = 0; i < 10; i++) {
      nummers[i] = rand.nextInt(100) + 1;
    } //end for loop
    return nummers;
  } //end numMaker
  
  /**
   * This method adds together the values of 2 int arrays of length 10.
   * It makes an array of length 10.
   * @param arr1 is the first int array.
   * @param arr2 is the second int array.
   * @return the array of sums.
   */
  static int[] sumMaker(int[] arr1, int[] arr2) {
    int[] sums = new int[10];
    for (int j = 0; j < 10; j++) {
      sums[j] = arr1[j] + arr2[j];
    } //end for loop
    return sums;
  } //end sumMaker
  
  /**
   * This method shows all the questions to the user again with their answer and the right answer.
   * @param firstNum is the first set of numbers.
   * @param secondNum is the second set of numbers.
   * @param answers is the sums of the two sets of numbers.
   * @param userInput is the user's already given answers.
   */
  static void reviewer(int[] firstNum, int[] secondNum, int[] answers, int[] userInput) {
    for (int n = 0; n < 10; n++) {
      System.out.println("Question " + (n + 1));
      System.out.printf("%2X", firstNum[n]);
      System.out.print(" + ");
      System.out.printf("%2X\n", secondNum[n]);
      System.out.print("The correct answer was ");
      System.out.printf("%2X\n", answers[n]);
      System.out.print("You answered ");
      System.out.printf("%2X\n", userInput[n]);
      if (answers[n] == userInput[n]) {
        System.out.println("You got it!");
      } else {
        System.out.println("You missed that one.");
      }
    } //end of for loop
  } //end of reviewer
  
  /**
   * This method checks that the userInput matches the sums or correct answers.
   * @param sums is the array of sums made above.
   * @param userInput is the user's answers.
   * @return a score of 10 points per correct answer.
   */
  static int grader(int[] sums, int[] userInput) {
    int score = 0;
    for (int y = 0; y < 10; y++) {
      if (sums[y] == userInput[y]) {
        score += 10;
      } //end of if
    } //end of for loop
    return score;
  } //end of grader

} //end of class
