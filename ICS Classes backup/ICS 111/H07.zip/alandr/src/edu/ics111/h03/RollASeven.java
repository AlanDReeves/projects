package edu.ics111.h03;

import java.util.Random;

/**This class simulates rolling dice until a sum of 7 is reached.
 * @author Alan Reeves
 */
public class RollASeven {

  /**This is the main method.
   * @param args not used.
   */
  public static void main(String[] args) {
    //establish variables and roll dice once
    Random rand = new Random(); //Creates a random object
    int counter = 1;
    int die1 = rand.nextInt(6) + 1;
    int die2 = rand.nextInt(6) + 1;
    int sum = die1 + die2;
    //establish variables and roll initial dice
    
    System.out.println("Roll " + counter);
    System.out.print("Die 1 comes up " + die1 + "  ");
    System.out.println("Die 2 comes up " + die2);
    System.out.println("The sum is " + sum);
    //report initial rolls to the user
    
    if (sum == 7) { //check if a 7 was rolled
      System.out.print("7 was rolled in " + counter + " Attempts");
    } else { //if not, reroll
      while (sum != 7) {
        die1 = rand.nextInt(6) + 1;
        die2 = rand.nextInt(6) + 1;
        sum = die1 + die2;
        counter = counter + 1; //count number of attempts
         
        System.out.println("Roll " + counter);
        System.out.print("Die 1 comes up " + die1 + "  ");
        System.out.println("Die 2 comes up " + die2);
        System.out.println("The sum is " + sum);
         
      } //end of while
      System.out.println("that took " + counter + " attempts"); 
      //print number of rolls when 7 is reached
    } //end of else
    
  } //end of main

} //end of class
