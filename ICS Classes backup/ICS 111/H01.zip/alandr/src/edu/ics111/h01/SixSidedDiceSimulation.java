package edu.ics111.h01;

/**
 * Six sided die simulation.
 * @author Alan Reeves
 */

public class SixSidedDiceSimulation {
  /** 
   * This is the main method.
   * @param args not used.
   * */
  public static void main(String[] args) {
    int firstRoll = (int) (6 * Math.random() + 1);
    int secondRoll = (int) (6 * Math.random() + 1);
    int total = secondRoll + firstRoll;
    
    System.out.println("The First Die comes Up " + firstRoll);
    System.out.println("The Second Die comes Up " + secondRoll);
    System.out.println("Your Total Roll Is " + total);
    //This class was made with input from TA Vincent Chan.
  }

}
