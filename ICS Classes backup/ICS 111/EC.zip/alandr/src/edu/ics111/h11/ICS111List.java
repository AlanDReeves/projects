package edu.ics111.h11;

/**
 * This interface describes an array that holds strings, with several functions.
 * @author Alan Reeves.
 */
public interface ICS111List {
  
  /**
   * This method gets the size of the array.
   * @return the number of strings in the array.
   */
  int size(); // return the number of strings in the array.
  
  /**
   * This method adds a string to the array.
   * @param s the string to be added.
   * @return boolean true.
   */
  boolean add(String s); // Adds s to the end of the array. Returns true.
  
  /**
   * This method inserts a string into a specific place in the array.
   * @param index the desired array index.
   * @param s the string to be added.
   * @return boolean true.
   */
  boolean add(int index, String s); // Inserts s into position index
  
  /**
   * Retrieves the string stored at a specific index.
   * @param index the index of the desired string.
   * @return the string at the given index.
   */
  String get(int index); // Returns the string at index.
  
  /**
   * Replaces a string in the array with another one.
   * @param index the index of the string to replace.
   * @param s the string to add.
   * @return the string being replaced.
   */
  String set(int index, String s); // Replaces the string at index with s. Returns old value.
  
  /**
   * Removes the string at a certain index.
   * @param index the index of the string to remove.
   * @return the string removed.
   */
  String remove(int index); // Removes the string at index. Returns string.
  
  /**
   * Removes a string if it is found in the array.
   * @param s the string to remove.
   * @return boolean true or false if the string was or was not in the array.
   */
  boolean remove(String s); // Removes s from the array, returns true if s was in the array.
  
  /**
   * Returns the index of a string if it is found in the array.
   * @param s the string to search for.
   * @return the index of the string if found or -1 if string not found.
   */
  int indexOf(String s); // Returns the index of s or -1 if s is not in the array.
  
  /**
   * Returns a string representation of the array.
   * @return the array as a string.
   */
  String toString(); // Returns a string representation of the array.
}
