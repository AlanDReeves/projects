package edu.ics111.h11;

/**
 * This class is an array that holds strings.
 * The number of strings is variable and the strings can be sorted by length.
 * @author Alan Reeves.
 */
public class DynamicArrayOfStrings implements ICS111List, Sortable {
  
  String[] strings;
  
  /**
   * Constructor.
   */
  public DynamicArrayOfStrings() {
    strings = new String[0];
  }

  @Override
  public void sort() {
    int arrLength = strings.length;
    for (int i = 0; i < arrLength - 1; i++) { //counts to one less than arrLength
      for (int j = 0; j < arrLength - i - 1; j++) { //increments to the right in the array
        //if (strings[j].length() > strings[j + 1].length()) { 
        //line above used if wanting to sort by increasing length.
        if (strings[j].compareTo(strings[j + 1]) > 0) {
          String key = strings[j + 1];
          strings[j + 1] = strings[j];
          strings[j] = key;          
        }
      }
    }
    
  }

  @Override
  public int size() {
    return strings.length;
  }

  @Override
  public boolean add(String s) {
    String[] temp = new String[(strings.length) + 1];
    for (int c = 0; c < strings.length; c++) {
      temp[c] = strings[c];
    }
    temp[strings.length] = s;
    strings = temp;
    return true;
  }

  @Override
  public boolean add(int index, String s) {
    String[] temp = new String[(strings.length) + 1];
    for (int i = 0; i < index; i++) {
      temp[i] = strings[i];
    }
    temp[index] = s;
    for (int j = index; j < strings.length; j++) {
      temp[j + 1] = strings[j];
    }
    strings = temp;
    
    return true;
  }

  @Override
  public String get(int index) {
    return strings[index];
  }

  @Override
  public String set(int index, String s) {
    String temp = strings[index];
    strings[index] = s;
    return temp;
  }

  @Override
  public String remove(int index) {
    String[] temp = new String[(strings.length) - 1];
    for (int i = 0; i < index; i++) {
      temp[i] = strings[i];
    }
    for (int j = index; j < temp.length; j++) {
      temp[j] = strings[j + 1];
    }
    String deleted = strings[index];
    strings = temp;    
    return deleted;
  }

  @Override
  public boolean remove(String s) {
    if (indexOf(s) > -1) {
      String[] temp = new String[(strings.length) - 1];
      for (int i = 0; i < indexOf(s); i++) {
        temp[i] = strings[i];
      }
      for (int j = indexOf(s); j < temp.length; j++) {
        temp[j] = strings[j + 1];
      }
      strings = temp;
      return true;
    }
    
    return false;
  }

  @Override
  public int indexOf(String s) {
    for (int i = 0; i < strings.length; i++) {
      if (strings [i].equals(s)) {
        return i;
      }
    }
    return -1;
  }
  
  /**
   * This method gives the contents of the whole array as a string.
   * Members are separated by brackets.
   * @return every entry in the array as one string.
   */
  public String toString() {
    String ret = "";
    for (int j = 0; j < strings.length; j++) {
      ret += "[";
      ret += strings[j] + "] ";
    }
    
    return ret;
  }
  
  

}
