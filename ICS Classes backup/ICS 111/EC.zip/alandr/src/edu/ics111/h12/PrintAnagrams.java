package edu.ics111.h12;

/**
 * This class prints anagrams of an entered string recursively.
 * @author Alan Reeves.
 */
public class PrintAnagrams {
  
  /**
   * This method prints anagrams of the word entered.
   * @param prefix enter an empty string.
   * @param word the word to make anagrams from.
   */
  public void printAnagrams(String prefix, String word) {
    if (word.length() == 0) {
      System.out.println(prefix);
    } else {
      for (int i = 0; i < word.length(); i++) {
        String newPrefix = prefix + word.charAt(i);
        String newWord = word.substring(0,i) + word.substring(i + 1,word.length());
        printAnagrams(newPrefix,newWord);
      }     
    }
  }
}
