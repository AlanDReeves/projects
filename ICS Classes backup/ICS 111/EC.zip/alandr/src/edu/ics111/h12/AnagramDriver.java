package edu.ics111.h12;

import java.util.Scanner;

/**
 * This is a driver class for PrintAnagrams.
 * @author Alan Reeves.
 */
public class AnagramDriver {

  /**
   * This is the main method.
   * @param args not used.
   */
  public static void main(String[] args) {
    
    Scanner scan = new Scanner(System.in);
    System.out.println("Please input a series of characters and then press enter.");
    String word = scan.next();
    System.out.println("The following are all of the possible anagrams of your input:");
    System.out.println();
    PrintAnagrams test = new PrintAnagrams();
    test.printAnagrams("", word);
    scan.close();
  }

}
