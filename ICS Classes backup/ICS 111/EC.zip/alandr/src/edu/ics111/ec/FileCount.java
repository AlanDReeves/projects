package edu.ics111.ec;

import java.io.File;

/**
 * This class counts the files in a directory supplied in args.
 * Made based off the example in the class web site.
 * @author Alan Reeves
 */
public class FileCount {

  /**
   * This is the main method.
   * @param args the starting file path.
   */
  public static void main(String[] args) {
    String path = "";
    try {
      path = args[0];
    } catch (ArrayIndexOutOfBoundsException e) {
      path = "."; // current directory
    }
    int count = countFiles(new File(path));
    System.out.println("number of files: " + count);
  }

  /**
   * This method counts all the files in a directory.
   * @param f the file or directory to be counted.
   * @return the number of files found.
   */
  public static int countFiles(File f) {
    if (f.isFile()) {
      return 1;
    }
    int count = 0;
    File[] files = f.listFiles();
    if (files == null) {
      return 0;
    }
    for (int i = 0; i < files.length; i++) {
      count = count + countFiles(files[i]);
    }
    return count;
  }
}
