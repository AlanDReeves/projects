package edu.ics111.h03;

import java.util.Random;
import java.util.Scanner;

/**
 * This class rolls two dice until the sum matches a user inputed number.
 * @author Alan Reeves
 */
public class ChooseARoll {
  /**
  * This is the main method.
  * @param args not used.
  */
  public static void main(String[] args) {
    
    System.out.println("Please enter a whole number between 2 and 12.");
    System.out.println("Two dice will be rolled until the total roll reaches your number");
    //ask user for input number
        
    Scanner keyboard = new Scanner(System.in);
    int userInput = keyboard.nextInt();
    //store user input
    
    while (userInput < 2 || userInput > 12) { //ask user again if input doesn't work
      System.out.println("That number doesn't work.");
      System.out.println("Please enter a whole number between 2 and 12");
      userInput = keyboard.nextInt();
    } //end of while
    
    Random rand = new Random();
    int counter = 1;
    int die1 = rand.nextInt(6) + 1;
    int die2 = rand.nextInt(6) + 1;
    int sum = die1 + die2; //roll dice
    
    System.out.println("Roll " + counter);
    System.out.print("Die 1 comes up " + die1);
    System.out.println("  Die 2 comes up " + die2);
    System.out.println("The sum is " + sum);
    //report initial roll
    
    if (sum == userInput) { //check if user's number was rolled
      System.out.print("Your number was rolled in " + counter + " Attempts");
    } else { //if not, keep rolling
      while (sum != userInput) {
        die1 = rand.nextInt(6) + 1;
        die2 = rand.nextInt(6) + 1;
        sum = die1 + die2;
        counter = counter + 1; //count number of attempts
         
        System.out.println("Roll " + counter);
        System.out.print("Die 1 comes up " + die1 + "  ");
        System.out.println("Die 2 comes up " + die2);
        System.out.println("The sum is " + sum);
      } //end of while
      
      System.out.println(userInput + " Was reached in " + counter + " Rolls");
      //final report
      
    } //end of else
    keyboard.close();
  } //end of main
    
} //end of class