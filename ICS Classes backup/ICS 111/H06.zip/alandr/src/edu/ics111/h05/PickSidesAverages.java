package edu.ics111.h05;

import edu.ics111.h04.TextIO;

/**
 * This class allows the user to choose a number of sides for two dice,
 * then finds the average number of rolls to reach each possible sum of rolls.
 * Uses PickSidesHelper class.
 * @author Alan Reeves
 */
public class PickSidesAverages {

  /**
   * This is the main method.
   * @param args is not used.
   */
  public static void main(String[] args) {
    
    //ask user for number of sides   
    int input = -1;
    do {
      System.out.println("Please enter a whole number of sides (at least 1) for two dice.");
      System.out.println("This program will calculate the average number of rolls");
      System.out.println("required to reach every possible sum of rolls.");
      input = TextIO.getInt();
    } while (input < 1);
    //Try/Catch covered by TextIO
    //set number of sides
    PickSidesHelper help = new PickSidesHelper();
    help.setSides(input);
   
    //roll dice of x number of sides until target sum reached
    for (int j = 2; j <= (input * 2); j++) { //cycle through all possible sums
      double totalRolls = 0;
      for (int i = 1; i <= 100; i++) { //repeat 100 times
        totalRolls += help.rollTarget(j);
      } //end of inner loop
      //calculate average
      double averageRolls = totalRolls / 100;
      
      //print out average
      System.out.println("Sum " + j + " took " + averageRolls + " rolls on average.");
          
    } //end of outer loop
    
  }

}
