package edu.ics111.h05;

/**
 * This class contains subroutines for PickSidesAverages.
 * @author Alan Reeves.
 */
public class PickSidesHelper {
  int target;
  int sides;
  int sum;
  int numrolls;
  double totalRolls;
  double averageRolls;
  
  /**
   * This method sets the number of sides.
   * @param sides is the number of sides for future dice rolls.
   */
  public void setSides(int sides) {
    this.sides = sides;
  } // End of setSides
  
  /**
   * This method sets the target sum for future rolls.
   * @param target is target sum.
   */
  public void setTarget(int target) {
    this.target = target;
  } // End of setTarget
  
  /**This method rolls two dice of a variable number of sides.
   * @param sides is number of sides on dice.
   * @return sum of roll.
   */
  public int rollDice(int sides) {
    int die1 = (int) ((Math.random() * this.sides) + 1);
    int die2 = (int) ((Math.random() * this.sides) + 1);
    this.sum = die1 + die2;
    return this.sum;
  } // end of rollDice
  
  /**
   * This method finds the number of rolls required to reach a target sum.
   * @param target is desired sum.
   * @return total number of rolls as a double.
   */
  public double rollTarget(int target) {
    this.totalRolls = 0;
    do {
      rollDice(this.sides);
      this.totalRolls += 1.0;
    } while (this.sum != target);
    
    return this.totalRolls;
  }
  
  

} // End of class
