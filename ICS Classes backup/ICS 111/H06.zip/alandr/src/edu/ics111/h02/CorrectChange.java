package edu.ics111.h02;

import java.util.Scanner;
/**
 * A program that calculates the correct amount of change.
 * Uses dollars, quarters, dimes, nickels, and pennies.
 * @author Alan Reeves.
 */

public class CorrectChange {
  /**
   * This is the main method.
   * @param args not used.
   */  

  public static void main(String[] args) {
    
    Scanner keyboard = new Scanner(System.in);
    
    System.out.println("How much does the item cost  ");
    double price = keyboard.nextDouble();
    
    System.out.println("How much was paid?  ");
    double payment = keyboard.nextDouble();
    
    double change = payment - price;
    
    if (change < 0) { //What to do if payment isn't enough
      System.out.print("Insufficient payment"); 
    } else {
    
      System.out.print("Change is  $");
      System.out.printf("%1.2f", change);
      System.out.println();
      //Previously this caused very small decimal amounts of cents so using printf cuts those off.
      //Change is still a double here
    
      int changeCents = (int) (change * 100);
      int dollars = changeCents / 100;
      //Converting change into cents so that I can do integer math.
    
      System.out.print("That's ");
      System.out.print(dollars + " Dollars ");
    
      changeCents = changeCents % 100;
      int quarters = changeCents / 25;
      changeCents = changeCents % 25;
      System.out.print(quarters + " Quarters ");
      //Using % to find a remainder and continuing on with that as the new amount of change.
    
      int dimes = changeCents / 10;
      changeCents = changeCents % 10;
      System.out.print(dimes + " Dimes ");
    
      int nickels = changeCents / 5;
      changeCents = changeCents % 5;
      System.out.print(nickels + " Nickels and ");
    
      System.out.print(changeCents + " Pennies ");
      //Do not need to divide or % by 1
    } //end of else statement
   
    
    keyboard.close();
    //Closing the keyboard to avoid warnings instead of suppressing them.
    //This class was made with advice from TA Vincent Chan.
  } //end of main

} //end of class
