
package edu.ics111.h09;

import java.awt.Color;
import java.awt.Graphics;

/**
 * This class is used to graphically represent dice.
 * Made based off example by TA Vincent Chan and DicePanel class in the text.
 * @author Alan Reeves.
 */
public class GraphicalPairOfDice extends PairOfDice {
  
  /**
   * Constructor method.
   */
  public GraphicalPairOfDice() {
    super();
  } //end of constructor
  
  
  /**
   * This method draws dice based on the roll values.
   * @param g Graphic.
   * @param val Value of the roll (1 die.
   * @param x x axis coordinate.
   * @param y y axis coordinate.
   */
  public void drawDie(Graphics g, int val, int x, int y) {
    g.setColor(Color.white);
    g.fillRect(x, y, 35, 35);
    g.setColor(Color.black);
    g.drawRect(x, y, 34, 34);
    // upper left dot
    if (val > 1) {
      g.fillOval(x + 3, y + 3, 9, 9);
    }
    // upper right dot
    if (val > 3) {
      g.fillOval(x + 23, y + 3, 9, 9);
    }
    // middle left dot
    if (val == 6) {
      g.fillOval(x + 3, y + 13, 9, 9);
    }
    // middle dot
    if (val % 2 == 1) {
      g.fillOval(x + 13, y + 13, 9, 9);
    }
    // middle right dot
    if (val == 6) {
      g.fillOval(x + 23, y + 13, 9, 9);
    }
    // bottom left dot
    if (val > 3) {
      g.fillOval(x + 3, y + 23, 9, 9);
    }
    // bottom right dot
    if (val > 1) {
      g.fillOval(x + 23, y + 23, 9, 9);
    }
  }

} //end of class
