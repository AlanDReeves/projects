package edu.ics111.h01;

import java.util.Random;

/**
 * Twenty Sided Dice Simulation.
 * @author Alan Reeves
 */
public class TwentySidedDiceSimulation {
  /**
   * This is the main method.
   * @param args not used.
   */
  public static void main(String[] args) {
    Random rand = new Random(); //Creates a random object
    
    int die1 = rand.nextInt(20) + 1;
    int die2 = rand.nextInt(20) + 1;
    int total = die1 + die2;
    
    System.out.println("Your First Die Comes Up " + die1);
    System.out.println("Your Second Die Comes Up " + die2);
    System.out.println("Your Total Roll is " + total);
    //Based on but not totally copied from geeksforgeeks.org/java-program-to-add-two-numbers.
    //This code was also made with advice from TA Vincent Chan.
  }

}
