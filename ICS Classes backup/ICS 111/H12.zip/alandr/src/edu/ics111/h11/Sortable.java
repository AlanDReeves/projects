package edu.ics111.h11;

/**
 * This interface represents a sortable array.
 * @author Alan Reeves.
 */
public interface Sortable {
  
  /**
   * Sorts the array in increasing order.
   */
  void sort();

}
