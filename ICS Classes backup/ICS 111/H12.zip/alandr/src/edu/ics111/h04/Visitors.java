package edu.ics111.h04;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 * This class reads from a file and calculates average amount spent for visitors from each country.
 * @author Alan Reeves
 */

public class Visitors {
  /**
   * This is the main method.
   * @param args not used.
   */

  public static void main(String[] args) {
    File visitorData = new File("visitors.dat"); //assign the file to a variable
    Scanner inFile = null; //create a scanner
    try {
      inFile = new Scanner(visitorData); 
      
    } catch (FileNotFoundException e) {
      System.out.println("visitors.dat file not found");
      System.exit(-1);      
    } //end of catch
    
    int totalVisitors = 0;
    double totalDollars = 0;
    int notAvailable = 0;
    
    //read until end of file
    while (inFile.hasNextLine()) { //checking to see if there is more to read
      String currentLine = inFile.nextLine();
      String[] tokens = currentLine.split(":"); //splits each line into an array of strings
      if (tokens.length < 3) { //no data available case
        notAvailable++;
        System.out.println(tokens[0] + " is missing data");
      } else {
        tokens[1] = tokens[1].trim(); //turn strings into usable numbers
        tokens[2] = tokens[2].trim();
        int countryVisitors = Integer.parseInt(tokens[1]); //store temporarily for use
        double countryDollars = Double.parseDouble(tokens[2]);
        
        totalVisitors += countryVisitors; //add up total visitors from slot 1
        totalDollars += countryDollars; //add up total dollars from slot 2
        System.out.println("The total number of visitors from " + tokens[0] + " is");
        System.out.println(tokens[1]);
        System.out.printf("The average amount spent is $" + (countryDollars / countryVisitors));
        System.out.println();
           
      } //end of else
           
    } //end of while
    System.out.println("Total visitors is " + totalVisitors);
    System.out.printf("Total spending is: $%,1.2f\n", totalDollars);
    System.out.printf("Average spent is: $%,1.2f\n", (totalDollars / totalVisitors));
    System.out.print("The total number of countries missing data is " + notAvailable);    
  }
    
}

