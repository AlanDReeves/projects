package edu.ics111.h08;

import java.util.Scanner;

/**
 * This class administers a hexidecimal addition quiz using the HexAdditionQuestion class.
 * @author Alan Reeves
 */
public class HexAdditionQuiz {  

  /**
   * This is the main method.
   * @param args not used.
   */
  public static void main(String[] args) {
    //make an array of hex addition questions
    HexAdditionQuestion[] quiz = new HexAdditionQuestion[10];
    for (int i = 0; i < 10; i++) {
      HexAdditionQuestion question = new HexAdditionQuestion();
      quiz[i] = question;
    } //end of making array loop
    
    //Loop 10 times {
    //ask the user a hexadecimal addition question from the array
    //save the user's answer
    // } end loop
    
    int[] userAnswers = new int[10];
    Scanner keyboard = new Scanner(System.in);
    String input;
    for (int i = 0; i < 10; i++) {
      System.out.println(quiz[i].getQuestion());
      boolean done = false;
      while (!done) {
        input = keyboard.nextLine();
        try {
          userAnswers[i] = Integer.parseInt(input,16);
          done = true;
        } catch (java.lang.NumberFormatException e) {
          System.out.println("Please input a number in hexadecimal.");
        } //end of catch
      } //end of while loop
    } //end of question asking loop
    
    //print each set of numbers with the user's answer
    //check if the user's answers were right and report results
    System.out.println("That's all the questions.");
    reviewer(quiz, userAnswers);
    
    
    //give the user 10 points per correct answer, tell them their score.
    int userScore = grader(quiz, userAnswers);
    System.out.println("Your score is " + userScore);
    if (userScore <= 50) {
      System.out.println("You may want to brush up on this.");
    } else if (userScore > 50) {
      System.out.println("Not bad.");
    } //end of else/if

    keyboard.close();
  } //end of main
  
  /**
   * This method reviews the questions and the user's answers.
   * @param quiz is the array of Hex addition questions.
   * @param userAnswers is the array of the user's answers as ints.
   */
  private static void reviewer(HexAdditionQuestion[] quiz, int[] userAnswers) {
    System.out.println("Let's see how you did.");
    System.out.println();
    for (int i = 0; i < 10; i++) {
      System.out.print("Question " + (i + 1) + " ");
      System.out.println(quiz[i].getQuestion());
      System.out.print("You answered: ");
      System.out.printf("%2X\n", userAnswers[i]);
      
      System.out.println("The correct answer was: " + quiz[i].correctAnswerAsHex());
      if (quiz[i].getCorrectAnswer() == userAnswers[i]) {
        System.out.println("You got it right!");
      } else {
        System.out.println("You got it wrong.");
      } //end of else
    } //end of for loop
  } //end of reviewer
  
  /**
   * This method grades the user's answers against the correct answers.
   * @param quiz is the array of hex addition questions.
   * @param userAnswers is the array of the users answers as ints.
   * @return the score with 10 points per right answer.
   */
  private static int grader(HexAdditionQuestion[] quiz, int[] userAnswers) {
    int score = 0;
    for (int i = 0; i < 10; i++) {
      if (quiz[i].getCorrectAnswer() == userAnswers[i]) {
        score += 10;
      } //end of if
    } //of for loop
    return score;
  } //end of grader

} //end of class
