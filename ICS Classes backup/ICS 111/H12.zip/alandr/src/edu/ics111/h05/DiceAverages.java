package edu.ics111.h05;

import java.util.Random;

/**
 * This class finds the average number of dice rolls to get each value.
 * @author Alan Reeves
 */
public class DiceAverages {

  /**
   * This is the main method.
   * @param args not used.
   */
  public static void main(String[] args) {
    
    System.out.println("Average number of tries");
    System.out.println("Number : Tries");
    
    for (int i = 2; i <= 12; i++) { //Tries each possible sum
      double totalRolls = 0;
      for (int j = 1; j <= 100; j++) { //Repeats until desired sum reached 100 times
        totalRolls += diceRoller(i); // Call diceRoller subroutine
      } // end inner
      double averageRolls = totalRolls / 100;
      System.out.print("Sum " + i + " : ");
      System.out.println(averageRolls + " rolls on average");
    } //end outer

  } //end of main
 
  /**
   * This method rolls two six sided dice and find the sum.
   * @param target is desired sum.
   * @return number of rolls until target reached.
   */
  private static int diceRoller(int target) {
    Random rand = new Random();
    int count = 0;
    int die1 = 0;
    int die2 = 0;
    int sum = die1 + die2;
    while (sum != target) {
      die1 = rand.nextInt(6) + 1;
      die2 = rand.nextInt(6) + 1;
      sum = die1 + die2;      
      count++;
    }
    return count;
  } //end of diceRoller
  

} //end of class
