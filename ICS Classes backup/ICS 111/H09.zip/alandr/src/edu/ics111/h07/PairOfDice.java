package edu.ics111.h07;

/**
 * This class rolls dice and returns the result as an array.
 * @author Alan Reeves
 */
public class PairOfDice {
  /**
   * This method rolls two 6 sided dice.
   * @return an array containing the values of the two rolls.
   */
  public static int[] rollDice() {
    int[] rolls = new int[2];
    rolls[0] = (int) (Math.random() * 6) + 1;
    rolls[1] = (int) (Math.random() * 6) + 1;
    return rolls;
  } // end rollDice
  
  
} //end of class


//constructor
//roll method to change numbers
//getter methods