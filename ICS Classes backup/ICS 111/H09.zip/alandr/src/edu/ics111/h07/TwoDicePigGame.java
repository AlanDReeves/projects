package edu.ics111.h07;

import java.util.Scanner;

/**
 * This class works with Player class to play a game.
 * @author Alan Reeves.
 */
public class TwoDicePigGame {
  

  /**
   * This is the main method, it runs the game.
   * @param args is not used.
   */
  public static void main(String[] args) {
    // TODO Auto-generated method stub
    //ask for number of players
    int numPlayers = 2;
    boolean done = false;
    Scanner keyboard = new Scanner(System.in);
    while (!done) {
      System.out.println("How many players are there?");
      try {
        numPlayers = keyboard.nextInt();
        done = true;
      } catch (java.util.InputMismatchException e) {
        System.out.println("Please enter a whole number");
        keyboard.nextLine(); //clears the scanner to avoid an infinite loop
      } //end of catch
    } //end of while
    
    //create player objects
    //place players in array
    Player[] players = new Player[numPlayers];
    for (int i = 0; i < numPlayers; i++) {
      System.out.println("What's is the name of player " + (i + 1) + " ?");
      String name = keyboard.next();
      Player player = new Player(name, 0);
      players[i] = player;
    } // end of for loop  
    
    
    // loop turns until a player reaches 100 score.
    int i = 0;
    while (true) {
      players[i].playerTurn(keyboard, 0);
      if (players[i].getScore() >= 100) {
        System.out.println(players[i].getName() + " wins! Score reached 100");
        break;
      } //end of if
      i += 1;
      if (i == players.length) {
        i = 0;
      } //resets to beginning of array
      System.out.println(); //add space so it's clear whose turn it is.
    } //end of while
    
    //end game at 100 points

    keyboard.close();
  } //end of main

} //end of class
