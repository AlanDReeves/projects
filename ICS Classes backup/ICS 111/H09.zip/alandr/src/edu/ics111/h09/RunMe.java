package edu.ics111.h09;


// I use the .* extension on import statements here because otherwise there would
// be 30 import statements. 
import java.awt.*;
import java.awt.event.*;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 * This class is used to run the other classes in the package.
 * When run, it opens a window with the graphical dice.
 * This class is heavily based on the Homework9 class by TA Vincent Chan.
 * @author Alan Reeves
 */
public class RunMe extends JPanel {
  /**
   * I'm not even going to pretend to know what this means.
   * Adding It doesn't seem to kill the program though.
   */
  private static final long serialVersionUID = 1L;
  private GraphicalPairOfDice dice;
  
  /**
   * Constructor.
   */
  public RunMe() {
    setPreferredSize(new Dimension(100, 100));
    setBackground(new Color(200, 200, 255));
    dice = new GraphicalPairOfDice();
    addMouseListener(new MouseAdapter() {

      public void mousePressed(MouseEvent evt) {
            dice.roll();
            repaint();
      }
      });
  }
  
  /**
   * This method is a modification of the usual paintComponent method.
   */
  public void paintComponent(Graphics g) {
    super.paintComponent(g);
    Graphics2D g2 = (Graphics2D) g;
    g2.setRenderingHint(
        RenderingHints.KEY_ANTIALIASING,
        RenderingHints.VALUE_ANTIALIAS_ON
    );
    g.setColor(Color.BLUE);
    g.drawRect(0, 0, 99, 99);
    g.drawRect(1, 1, 97, 97);
    // The drawDie() method is a method of the GraphicalPairOfDice class
    // So we need to use a GraphicalPairOfDice object to call drawDie()
    dice.drawDie(g, dice.getDie1(), 10, 10);
    dice.drawDie(g, dice.getDie2(), 55, 55);
  }

  /**
   * This is the main method.
   * @param args is not used.
   */
  public static void main(String[] args) {
    JFrame window = new JFrame("Dice: Click to Roll Again");
    RunMe content = new RunMe();
    window.setContentPane(content);
    window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    window.setLocation(120, 70);
    window.pack();
    window.setVisible(true);
  }

}

