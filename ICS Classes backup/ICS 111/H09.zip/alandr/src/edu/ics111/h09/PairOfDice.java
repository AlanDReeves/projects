package edu.ics111.h09;


/**
 * This class simulates a pair of dice.
 * I borrow this from the ICS 111 lab website.
 * @author I don't know.
 */
public class PairOfDice {
  private int die1;
  private int die2;

  /**
   * Constructor.
   * Rolls the dice once.
   */
  public PairOfDice() {
    roll();
  }

  /**
   * Resets the values of the dice.
   */
  public void roll() {
    die1 = (int) (6 * Math.random()) + 1;
    die2 = (int) (6 * Math.random()) + 1;
  }

  /**
   * Getter method for die 1.
   * @return Die 1's value.
   */
  public int getDie1() {
    return die1;
  }
  
  /**
   * Getter method for die 2.
   * @return Die 2's value.
   */
  public int getDie2() {
    return die2;
  }
}