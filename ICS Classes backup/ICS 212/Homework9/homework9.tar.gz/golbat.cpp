/************************************************************
//
//  Name:        Alan Reeves
//
//  Homework:    9
//
//  Class:       ICS 212
//
//  Instructor:  Ravi Narayan
//
//  Date:        December 9, 2024
//
//  File:        golbat.cpp
//
//  Description: 
//      This file defines the functions of the golbat class.
//
************************************************************/


#include<iostream>
#include"golbat.h"

using namespace std;

/***********************************************************
//
//  Function name:    default constructor
//
//  Description:      This is the default constructor. It 
//                    initializes the type and weight fields,
//                    and prints a message that it was called.
//
//  Parameters:       none
//
//  Return values:    none
//
************************************************************/

golbat::golbat()
{
    type = "Poison Flying";
    weight = 121.3;
    cout << "Golbat constructor" << endl;
}

/*************************************************************
//
//  Function name:    default destructor
//
//  Description:      Prints a message that this destructor was
//                    called.
//
//  Parameters:       none
//
//  Return values:    none
//
**************************************************************/

golbat::~golbat()
{
    cout << "Golbat destructor" << endl;
}

/***************************************************************
//
//  Function name:    printData()
//
//  Description:      prints the values in the type and weight fields
//
//  Parameters:       none
//
//  Return values:    none
//
****************************************************************/

void golbat::printData()
{
    cout << "Golbat " << this->type <<" " <<  this->weight << endl;
}
