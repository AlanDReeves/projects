/***********************************************************************
//
//  Name:        Alan Reeves
//
//  Homework:    9
//
//  Class:       ICS 212
//
//  Instructor:  Ravi Narayan
//
//  Date:        December 9, 2024
//
//  File:        pokemon.cpp
//
//  Description:
//      This file contains the functions for the pokemon class
//
*********************************************************************/

#include<iostream>
#include"pokemon.h"

using namespace std;

/********************************************************************
//
//  Function name:  default constructor
//
//  Description:    prints a message that this function was called.
//
//  Parameters:     none
//
//  Return values:  none
//
********************************************************************/
pokemon::pokemon()
{
    cout << "Pokemon Constructor" << endl;
}

/*******************************************************************
//
//  Function name:  default destructor
//
//  Description:    prints a message that this function was called.
//
//  Parameters:     none
//
//  Return values:  none
//
********************************************************************/
pokemon::~pokemon()
{
    cout << "Pokemon Destructor" << endl;
}
