/************************************************************
//
//  Name:        Alan Reeves
//
//  Homework:    9
//
//  Class:       ICS 212
//
//  Instructor:  Ravi Narayan
//
//  Date:        December 9, 2024
//
//  File:        magneton.cpp
//
//  Description:
//      Defines the functions for the magneton class.
//
************************************************************/

#include<iostream>
#include"magneton.h"

using namespace std;

/***********************************************************
//
//  Function name:  default constructor
//
//  Description:    initializes the type and weight fields. 
//                  Prints a message that the function was called.
//
//  Parameters:     none
//
//  Return values:  none
//
***********************************************************/

magneton::magneton()
{
    type = "Electric Steel";
    weight = 132.3;
    cout << "Magneton constructor" << endl;
}

/************************************************************
//
//  Function name:  default destructor
//
//  Description:    prints a message that the function was called
//
//  Parameters:     none
//
//  Return values:  none
//
************************************************************/

magneton::~magneton()
{
    cout << "Magneton destructor" << endl;
}

/****************************************************************
//
//  Function name:  printData
//
//  Description:    prints the values in the type and weight fields
//
//  Parameters:     none
//
//  Return values:  none
//
*****************************************************************/

void magneton::printData()
{
    cout << "Magneton " << this->type <<" " <<  this->weight << endl;
}
