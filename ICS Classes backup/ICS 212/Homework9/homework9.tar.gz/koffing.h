/*****************************************************
//
//  Name:        Alan Reeves
//
//  Homework:    9
//
//  Class:       ICS 212
//
//  Instructor:  Ravi Narayan
//
//  Date:        December 9, 2024
//
//  File:        koffing.h
//
//  Description: 
//      This file defines the koffing class, which is
//      a child of the pokemon class.
//
*****************************************************/

#ifndef _koffing_
#define _koffing_

#include"pokemon.h"

class koffing : public pokemon
{
    public:
        koffing();
        virtual ~koffing();
        void printData();
};

#endif
