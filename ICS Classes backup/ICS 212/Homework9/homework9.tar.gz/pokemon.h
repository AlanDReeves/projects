/*****************************************************************
//  NAME:        Alan Reeves
//  
//  HOMEWORK:    9
// 
//  CLASS:       ICS 212
//  
//  INSTRUCTOR:  Ravi Narayan
//  
//  DATE:        December 9, 2024
//  
//  FILE:        pokemon.h
//  
//  DESCRIPTION:
//  This header defines the pokemon class.
//
****************************************************************/
#ifndef _pokemon_
#define _pokemon_

#include<string>

using namespace std;

class pokemon
{
    protected:
        string type;
        float weight;

    public:
       pokemon();
       virtual ~pokemon();
       virtual void printData() = 0;
};

#endif
