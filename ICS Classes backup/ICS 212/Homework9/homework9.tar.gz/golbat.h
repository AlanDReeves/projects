/**********************************************************
//
//  Name:        Alan Reeves
//
//  Homework:    9
//
//  Class:       ICS 212
//
//  Instructor:  Ravi Narayan
//
//  Date:        December 9, 2024
//
//  File:        golbat.h
//
//  Description: 
//      This file defines the golbat class, which is a child
//      of the pokemon class.
//
***********************************************************/

#ifndef _golbat_
#define _golbat_

#include"pokemon.h"

class golbat : public pokemon
{
    public:
        golbat();
        virtual ~golbat();
        void printData();
};

#endif
