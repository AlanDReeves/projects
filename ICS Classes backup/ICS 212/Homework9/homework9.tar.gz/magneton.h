/******************************************************
//
//  Name:        Alan Reeves
//
//  Homework:    9
//
//  Class:       ICS 212
//
//  Instructor:  Ravi Narayan
//
//  Date:        December 9, 2024
//
//  File:        magneton.h
//
//  Description:
//      This file defines the magneton class, which is
//      a child of the pokemon class.
//
******************************************************/

#ifndef _magneton_
#define _magneton_

#include"pokemon.h"

class magneton : public pokemon
{
    public:
        magneton();
        virtual ~magneton();
        void printData();
};

#endif
