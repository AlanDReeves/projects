/************************************************************
//
//  Name:       Alan Reeves
//
//  Homework:   9
//
//  Class:      ICS 212
//
//  Instructor: Ravi Narayan
//
//  Date:       December 9, 2024
//
//  File:       driver.cpp
//
//  Description:
//    This file utilizes the class files for the assignment to
//    produce the required output.
//
*************************************************************/

#include"pokemon.h"
#include"magneton.h"
#include"koffing.h"
#include"golbat.h"
#include<vector>
#include<iostream>
#include<map>

using namespace std;

void checkPokedex(pokemon*);

/************************************************************
//
//  Function name:  main
//
//  Description:    utilizes the various child classes of pokemon
//                  as well as vectors and maps to produce output
//
//  Parameters:     none
//
//  Return values:  0: success
//
*************************************************************/


int main()
{
    pokemon *party[3];
    int i;
    vector<string> names;
    map<string, pokemon*> pokedex;

    cout << "Creating pokemon child class objects." << endl;

    party[0] = new magneton();
    party[1] = new koffing();
    party[2] = new golbat();

    names.push_back("Electro");
    cout << "adding Electro to vector." << endl;
    names.push_back("Koffee");
    cout << "adding Koffee to vector." << endl;
    names.push_back("Goldie");
    cout << "adding Goldie to vector." << endl;

    pokedex["Electro"] = party[0];
    cout << "adding Electro to map" << endl;
    pokedex["Koffee"] = party[1];
    cout << "adding Koffee to map" << endl;
    pokedex["Goldie"] = party[2];
    cout << "adding Goldie to map" << endl;

    cout << "checking nicknames in vector against map" << endl;

    for (i = 0; i < 3; i++)
    {
        cout << "nickname checked: " << names[i] << endl;
        cout << "print data output: ";
        checkPokedex(pokedex[names[i]]);
        cout << endl;
    }
   
    cout << "removing objects from heap" << endl;
    delete party[0];
    delete party[1];
    delete party[2];

    return 1;
}

/*************************************************************
//
//  Function name: checkPokedex
//
//  Description:   calls the print data function of a pokemon object
//                 using its pointer
//
//  Parameters:    pokemon (pokemon*) : a pointer to the pokemon
//                 whose function will be called.
//
//  Return values: none
//
**************************************************************/

void checkPokedex(pokemon *pokemon)
{
    pokemon->printData();
}
