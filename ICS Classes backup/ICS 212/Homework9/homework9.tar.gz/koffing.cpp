/******************************************************************
//
//  Name:        Alan Reeves
//
//  Homework:    9
//
//  Class:       ICS 212
//
//  Instructor:  Ravi Narayan
//
//  Date:        December 9, 2024
//
//  File:        koffing.cpp
//
//  Description:
//      This file defines the methods for the koffing class.
//
*****************************************************************/

#include<iostream>
#include"koffing.h"

using namespace std;

/******************************************************************
//
//  Function name:  default constructor
//
//  Description:    initializes the type and weight fields and prints
//                  a message that the function was called.
//
//  Parameters:     none
//
//  Return values:  none
//
*******************************************************************/

koffing::koffing()
{
    type = "Poison";
    weight = 2.2;
    cout << "Koffing constructor" << endl;
}

/******************************************************************
//
//  Function name:  default destructor
//
//  Description:    prints a message that the function was called.
//
//  Parameters:     none
//
//  Return values:  none
//
******************************************************************/

koffing::~koffing()
{
    cout << "Koffing destructor" << endl;
}

/******************************************************************
//
//  Function name:  printData
//
//  Description:    prints the type and weight fields
//
//  Parameters:     none
//
//  Return values:  none
//
******************************************************************/

void koffing::printData()
{
    cout << "Koffing " << this->type <<" " <<  this->weight << endl;
}
