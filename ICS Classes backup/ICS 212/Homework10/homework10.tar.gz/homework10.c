/*****************************************************************
//
//  NAME:        Alan Reeves
//
//  HOMEWORK:    1
//
//  CLASS:       ICS 212
//
//  INSTRUCTOR:  Ravi Narayan
//
//  DATE:        December 14, 2024
//
//  FILE:        homework10.c
//
//  DESCRIPTION:
//   This file contains the implementation of is_multiple3 for
//   the homework10.java file.
//
****************************************************************/

/*#include"/usr/java/jdk1.8.0_131/include/jni.h"
#include"/usr/java/jdk1.8.0_131/include/linux/jni_md.h"*/
#include<jni.h>
#include<jni_md.h>
#include"Homework10.h"

/*****************************************************************
//
//  Function name: is_multiple3
//
//  DESCRIPTION:   Checks if a given integer is divisible by 3
//
//  Parameters:    num (int) : the number to check
//
//  Return values:  0 : not divisible
//                 -1 : divisible
//
****************************************************************/

JNIEXPORT jint JNICALL 
Java_Homework10_is_1multiple3(JNIEnv * ptr, jclass cls, jint num)
{
    int result;

    if (num % 3 == 0)
    {
        result = 1;
    }
    else
    {
        result = 0;
    }
    return result;
}
