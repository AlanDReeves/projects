//***************************************************************
//
//  NAME:        Alan Reeves
//
//  HOMEWORK:    10
//
//  CLASS:       ICS 212
//
//  INSTRUCTOR:  Ravi Narayan
//
//  DATE:        December 14, 2024
//
//  FILE:        homework10.java
//
//  DESCRIPTION:
//   Contains the java methods for homework 10, calls
//   functions from homework10.c
//   Also contains the main method
//
//****************************************************************

import java.util.Scanner;
class Homework10
{
    static
    {
        System.loadLibrary("name");
    }

//****************************************************************
//
//  Function name: main
//
//  DESCRIPTION:   Calls user interface function and print table
//
//  Parameters:    argc (int) : The number of elements in argv
//                 argv (char*[]) : An array of arguments passed
//                                  to the program.
//
//  Return values:  none
//
//**************************************************************/

    public static void main (String[] args)
    {
        int num =  userInterface();
        System.out.println("NUMBER   Multiple of 3?");
        print_table(num);

    }    

//****************************************************************
//
//  Function name: userInterface
//
//  DESCRIPTION:   Introduces the program and asks for a max number
//
//  Parameters:    none
//
//  Return values: num (int) : the number obtained from the user
//
//**************************************************************/

    public static int userInterface()
    {
        Scanner scan = new Scanner(System.in);
        int num = -1;

        System.out.print("This program accepts an integer and ");
        System.out.print("shows if every number between the entered ");
        System.out.println("number and 0 is divisible by 3.");

        System.out.println("Please enter a number.");

        while (num <= 0)
        {
            try
            {
                num = scan.nextInt();
                if (num <= 0)
                {
                    System.out.println("You must enter an integer greater than 0");
                }
            }
            catch(Exception e)
            {
                System.out.println("You must enter an integer greater than 0");
                scan.nextLine();
            }
        }
        return num;
    }

//****************************************************************
//
//  Function name: print_table
//
//  DESCRIPTION:   prints a table of divisibility for every number
//                 between the one given as a parameter and 0.
//                 Calls a native C function to accomplish this.
//
//  Parameters:    maxNum (int) : the largest number to check
//
//  Return values: none
//
//***************************************************************/
    public static void print_table(int maxNum)
    {
        int result = 0, counter = 0;
        while (counter <=  maxNum)
        {
            System.out.printf("%6d" , counter);
            result = is_multiple3(counter);
            if (counter == 0)
            {
                result = 0;
            }
            if (result == 1)
            {
                System.out.println("   Yes");
            }
            else
            {
                System.out.println("    No");
            }
            counter += 1;
        }
    }

//***************************************************************
//
//  Function name:  is_multiple3
//
//  DESCRIPTION:    Determines if a given number is divisible by 3.
//                  This function is implemented in C
//
//  Parameters:     num (int) : the number to check
//
//  Return values:  0 : not divisible by 3
//                  1 : divisible by 3
//
//**************************************************************/
    public static native int is_multiple3(int num);

}//end of Homework10 class
