/*****************************************************************
//
//  NAME:        Alan Reeves
//
//  HOMEWORK:    7
//
//  CLASS:       ICS 212
//
//  INSTRUCTOR:  Ravi Narayan
//
//  DATE:        November 13, 2024
//
//  FILE:        homework7.c
//
//  DESCRIPTION:
//   This program reads a TSP header from a bin file, prints the information,
//   and makes a header for a reply.
//
****************************************************************/

#include<stdio.h>

int readFile(char [], unsigned char []);
int writeFile(char [], unsigned char[]);
void printHeader(unsigned char[]);
void makeHeader(unsigned char[], unsigned char[]);
void DEBUGGINGTOOL(unsigned char[]);

/*****************************************************************
//
//  Function name: main
//
//  DESCRIPTION:   main calls the other functions to read a header,
//                 print the data of the header, make and print a
//                 response header, and write that header to a file.
//
//  Parameters:    argc (int) : The number of elements in argv
//                 argv (char*[]) : An array of arguments passed
//                                  to the program.
//
//  Return values:  0 : completed without issue
//                 -1 : failed to complete
//
****************************************************************/

int main(int argc, char* argv[])
{
    char fileName[100], responseName[100];
    unsigned char request[20], response[20];
    int returnVal = -1, i = 0;

    if (argc < 3)
    {
        printf("Param 1: request filename, Param 2: desired response filename\n");
    }
    else if (argc > 3)
    {
        printf("Too many arguments.\n");
    }
    else
    {
        while (argv[1][i] != '\0')
        {
            fileName[i] = argv[1][i];
            i++;
        }
        i = 0;
        while (argv[2][i] != '\0')
        {
            responseName[i] = argv[2][i];
            i++;
        }
        fileName[99] = '\0';
        responseName[i] = '\0';

        readFile(fileName, request);
        printHeader(request);
        printf("\n\n\nStart of response header:\n");
        makeHeader(request, response);
        printHeader(response);

        writeFile(responseName, response);

        returnVal = 0;
    }
    return returnVal;
}

/*****************************************************************
//
//  Function name: readFile
//
//  DESCRIPTION:   Opens a binary file and records the first 20 bytes
//                 in an unsigned char array.
//
//  Parameters:    fileName (char []) : the name of the file.
//                 binArr   (unsigned char []) : an unsigned char array
//
//  Return values:  0 : read file without issue
//                 -1 : unable to read file
//
****************************************************************/
int readFile(char fileName[], unsigned char binArr[])
{
    FILE* pointer;
    int returnVal = 0;
    
    pointer = fopen(fileName, "rb");

    if (pointer == NULL)
    {
        returnVal = -1;
    }
    else
    {
        fread(binArr, sizeof(unsigned char), 20, pointer);
        returnVal = 0;
    }

    if (pointer != NULL)
    {
        fclose(pointer);
    }

    return returnVal;
}

/*******************************************************************************
//  Function name: writeFile
//
//  Description:   writes a header to a bin file
//
//  Parameters:    fileName (char[]) : the desired file name
//                 binArr (unsigned char[]) : the intended array to write to file
//
//  Return values: 0 : concluded succesfully
//                 -1 : failed to write for some reason
//
********************************************************************************/
int writeFile(char fileName[], unsigned char binArr[])
{
    FILE* pointer;
    int returnVal = 0;

    pointer = fopen(fileName, "wb");

    if (pointer == NULL)
    {
        returnVal = -1;
    }
    else
    {
        fwrite(binArr, sizeof(unsigned char), 20, pointer);
    }

    if (pointer != NULL)
    {
        fclose(pointer);
    }
    return returnVal;
}

/********************************************************************
//  Function name:  printHeader
//
//  DESCRIPTION:    prints the source port, destination port, sequence number,
//                  and acknowledgement number of a header stored in an array.
//
//  Parameters:     unsignedarr (unsigned char[]) : the stored header in an array.
//
//  Return values:  none
//
********************************************************************/
void printHeader(unsigned char unsignedarr[])
{
    int sourcePort, destinationPort;
    unsigned int sequenceNum, ackNum;

    sourcePort = unsignedarr[1] << 8;
    sourcePort += unsignedarr[0];

    destinationPort = unsignedarr[3] << 8;
    destinationPort += unsignedarr[2];

    sequenceNum = unsignedarr[7] << 24;
    sequenceNum += unsignedarr[6] << 16;
    sequenceNum += unsignedarr[5] << 8;
    sequenceNum += unsignedarr[4];

    ackNum = unsignedarr[11] << 24;
    ackNum += unsignedarr[10] << 16;
    ackNum += unsignedarr[9] << 8;
    ackNum += unsignedarr[8]; 

    printf("Source Port: %d\n", sourcePort);
    printf("Destination Port: %d\n", destinationPort);
    printf("Sequence Number: %u\n", sequenceNum);
    printf("Acknowledgement Number: %u\n", ackNum);
    
    printf("flags: ");
    if ((unsignedarr[13] & (1 << 5)) == (1 << 5))
    {
        printf("URG ");
    }
    if ((unsignedarr[13] & (1 << 4)) == (1 << 4))
    {
        printf("ACK ");
    }
    if ((unsignedarr[13] & (1 << 3)) == (1 << 3))
    {
        printf("PSH ");
    }
    if ((unsignedarr[13] & (1 << 2)) == (1 << 2))
    {
        printf("RST ");
    }
    if ((unsignedarr[13] & (1 << 1)) == (1 << 1))
    {    
        printf("SYN ");
    }
    if ((unsignedarr[13] & 1) == 1)
    {
        printf("FIN ");
    }
    printf("\n");
    
}

/*****************************************************************
 *
 *  Function name:  makeHeader
 *
 *  DESCRIPTION:    generates a header based on a previous request
 *
 *  parameters:     oldHeader (const unsigned char[]) : the request header
 *                  response (unsigned char[]) : a pointer to the array 
 *                    where the new header will be stored
 *
 *  return values:  none
 *
 *****************************************************************/
void makeHeader(unsigned char oldHeader[], unsigned char response[])
{
    int sourcePort, destinationPort, sourceGreater, mask, temp, i;
    unsigned int sequenceNum;

    /*copy over old header into response header for editing*/
    for (i = 0; i < 20; i++)
    {
        response[i] = oldHeader[i];
    }


    /*check if source port number > 0x7FFF*/
    sourcePort = response[1] << 8;
    sourcePort += response[0];

    if (((sourcePort >> 15) & 1) == 1)
    {
        sourceGreater = 1;
    }
    else
    {
        sourceGreater = 0;
    }
    /*toggle 4th and 11th bits if true*/
    if (sourceGreater == 1)
    {
        /*printf("had to swap bits\n");*/
        mask = (1 << 5) | (1 << 12);
        sourcePort = sourcePort ^ mask;
    }

    destinationPort = response[3] << 8;
    destinationPort += response[2];

    /*insert destinationPort variable where sourcePort was and vice-versa*/
    /*source port is in array[0] and [1], destination is array[2], [3]*/
    /*bits must be flipped like in original*/
    response[1] = (destinationPort >> 8);
    response[0] = (destinationPort & 0xFF);

    response[3] = (sourcePort >> 8);
    response[2] = (sourcePort & 0xFF);
    /*above code swaps source and destination ports while also reversing bits.*/
    temp = sourcePort;
    sourcePort = destinationPort;
    destinationPort = temp;
    /*swaps named variables*/

    /*set ackNum to the sequence number of the request header*/
    /*sequence number is in bytes 4, 5, 6, 7 (index 0)*/
    /*ack number is in bytes 8, 9, 10, 11*/
    response[8] = response[4];
    response[9] = response[5];
    response[10] = response[6];
    response[11] = response[7];

    /*set the sequence number to sequence number + 1*/
    sequenceNum = response[7] << 24;
    sequenceNum += response[6] << 16;
    sequenceNum += response[5] << 8;
    sequenceNum += response[4];

    sequenceNum += 1;

    response[7] = sequenceNum >> 24;
    response[6] = (sequenceNum >> 16) & 0xFF;
    response[5] = (sequenceNum >> 8) & 0xFF;
    response[4] = sequenceNum & 0xFF;
    /*above code extracts sequenceNum, increments by one, and places it back*/
    
    /*set ACK flag if SYN flag is set*/
    if ((response[13] & (1 << 1)) == (1 << 1))
    {
        response[13] = response[13] | (1 << 4);
    }
}
